import bpy
import math
import random

# RESET SCENE
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

# =========================================================================
# ⚙️ SYSTEM & RENDERING CONFIGURATION
# =========================================================================
scene = bpy.context.scene
scene.render.engine = 'BLENDER_EEVEE'
if hasattr(scene, "eevee"):
    if hasattr(scene.eevee, "taa_render_samples"):
        scene.eevee.taa_render_samples = 16
    else:
        scene.eevee.aa_samples = 16

# TIMELINE: Phase 1 (Tour: 1-240) + Phase 2 (Orbits: 241-1440) = 1440 Frames (60 Secs)
scene.frame_start = 1
scene.frame_end = 1440
scene.render.fps = 24
scene.render.resolution_x = 1280
scene.render.resolution_y = 1280

# 🌌 STARFIELD BACKGROUND
world = scene.world
world.use_nodes = True
nodes = world.node_tree.nodes
links = world.node_tree.links
nodes.clear()

bg = nodes.new(type='ShaderNodeBackground')
output = nodes.new(type='ShaderNodeOutputWorld')
noise = nodes.new(type='ShaderNodeTexNoise')
ramp = nodes.new(type='ShaderNodeValToRGB')
math_mult = nodes.new(type='ShaderNodeMath')

noise.inputs['Scale'].default_value = 500.0
noise.inputs['Detail'].default_value = 15.0
noise.inputs['Roughness'].default_value = 0.9
ramp.color_ramp.interpolation = 'CONSTANT'
ramp.color_ramp.elements[0].position = 0.63
ramp.color_ramp.elements[1].color = (1, 1, 1, 1)
math_mult.operation = 'MULTIPLY'
math_mult.inputs[1].default_value = 8.0

links.new(noise.outputs['Fac'], ramp.inputs['Fac'])
links.new(ramp.outputs['Color'], math_mult.inputs[0])
links.new(math_mult.outputs['Value'], bg.inputs['Color'])
links.new(bg.outputs['Background'], output.inputs['Surface'])

# =========================================================================
# 🛠️ SHADER ENGINE PIPELINES
# =========================================================================
def create_emissive_mat(name, color, strength):
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    nodes.clear()
    emit = nodes.new(type='ShaderNodeEmission')
    emit.inputs['Color'].default_value = color
    emit.inputs['Strength'].default_value = strength
    out = nodes.new(type='ShaderNodeOutputMaterial')
    mat.node_tree.links.new(emit.outputs['Emission'], out.inputs['Surface'])
    return mat

def create_emissive_texture_mat(name, texture_path, strength):
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    nodes.clear()
    
    tex = nodes.new(type='ShaderNodeTexImage')
    try:
        tex.image = bpy.data.images.load(texture_path)
    except:
        pass
        
    emit = nodes.new(type='ShaderNodeEmission')
    emit.inputs['Strength'].default_value = strength
    out = nodes.new(type='ShaderNodeOutputMaterial')
    
    mat.node_tree.links.new(tex.outputs['Color'], emit.inputs['Color'])
    mat.node_tree.links.new(emit.outputs['Emission'], out.inputs['Surface'])
    return mat

def create_diffuse_mat(name, texture_path, roughness=0.6):
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    nodes.clear()
    tex = nodes.new(type='ShaderNodeTexImage')
    try:
        tex.image = bpy.data.images.load(texture_path)
    except:
        pass
    bsdf = nodes.new(type='ShaderNodeBsdfPrincipled')
    bsdf.inputs['Roughness'].default_value = roughness
    out = nodes.new(type='ShaderNodeOutputMaterial')
    mat.node_tree.links.new(tex.outputs['Color'], bsdf.inputs['Base Color'])
    mat.node_tree.links.new(bsdf.outputs['BSDF'], out.inputs['Surface'])
    return mat

# Base fallback materials
orbit_line_mat = create_emissive_mat("OrbitLineMat", (0.3, 0.5, 1.0, 1.0), 1.5)
asteroid_mat = create_diffuse_mat("AsteroidMat", "C:/textures/moon.jpg", roughness=0.95)

# =========================================================================
# 🗺️ COSMIC DATA DICTIONARY
# =========================================================================
cosmic_manifest = {
    "Mercury":  {"rad": 0.18, "dist": 4.5,  "rev": 0.241,   "rot": 58.6,    "tilt": 0.03,  "tex": "C:/textures/mercury/mercury_color.jpg", "shape": "sphere"},
    "Venus":    {"rad": 0.32, "dist": 6.5,  "rev": 0.615,   "rot": -243.0,  "tilt": 177.3, "tex": "C:/textures/venus/venus_color.jpg",   "shape": "sphere"},
    "Earth":    {"rad": 0.35, "dist": 10.0, "rev": 1.000,   "rot": 1.0,     "tilt": 23.44, "tex": "C:/textures/earth/earth_color.jpg",   "shape": "sphere"}, 
    "Mars":     {"rad": 0.22, "dist": 13.5, "rev": 1.881,   "rot": 1.026,   "tilt": 25.19, "tex": "C:/textures/mars/mars_color.jpg",    "shape": "sphere"}, 
    "Jupiter":  {"rad": 0.85, "dist": 18.0, "rev": 11.86,   "rot": 0.414,   "tilt": 3.13,  "tex": "C:/textures/jupiter/jupiter_color.jpg", "shape": "sphere"},
    "Saturn":   {"rad": 0.72, "dist": 23.0, "rev": 29.46,   "rot": 0.444,   "tilt": 26.73, "tex": "C:/textures/saturn/saturn_color.jpg",  "shape": "oblate"},
    "Uranus":   {"rad": 0.52, "dist": 27.5, "rev": 84.01,   "rot": -0.718,  "tilt": 97.77, "tex": "C:/textures/uranus/uranus_color.jpg",  "shape": "sphere"},
    "Neptune":  {"rad": 0.50, "dist": 31.5, "rev": 164.8,   "rot": 0.671,   "tilt": 28.32, "tex": "C:/textures/neptune/neptune_color.jpg", "shape": "sphere"},
    "Pluto":    {"rad": 0.12, "dist": 37.0, "rev": 248.0,   "rot": -6.387,  "tilt": 122.5, "tex": "C:/textures/pluto/pluto_color.jpg",   "shape": "sphere"},
}

# =========================================================================
# 🏛️ GENERATING GEOMETRY, ORBIT LINES, & CELESTIAL BODIES
# =========================================================================
system_registry = {}
random.seed(4321)

# 1. THE SUN
sun_mat = create_emissive_texture_mat("SunMat", "C:/textures/sun/sun.jpg", 3.5)
bpy.ops.mesh.primitive_uv_sphere_add(segments=64, ring_count=32, radius=2.5)
sun_obj = bpy.context.object
sun_obj.name = "Sun"
sun_obj.data.materials.append(sun_mat)
bpy.ops.object.shade_smooth()
system_registry["Sun"] = sun_obj

def build_orbit_ring(radius, name):
    bpy.ops.mesh.primitive_torus_add(align='WORLD', location=(0,0,0), major_radius=radius, minor_radius=0.012, major_segments=128, minor_segments=6)
    ring = bpy.context.object
    ring.name = f"Orbit_Line_{name}"
    ring.data.materials.append(orbit_line_mat)
    bpy.ops.object.shade_smooth()

# 2. RUN GENERATION ENGINE FOR THE PLANETARY CORES
for name, body in cosmic_manifest.items():
    build_orbit_ring(body["dist"], name)
    
    bpy.ops.object.empty_add(type='PLAIN_AXES', location=(0, 0, 0))
    pivot = bpy.context.object
    pivot.name = f"{name}_Orbit_Pivot"
    
    if body["shape"] == "oblate":
        bpy.ops.mesh.primitive_uv_sphere_add(segments=48, ring_count=24, radius=body["rad"])
        planet = bpy.context.object
        planet.scale.z = 0.84
    else:
        bpy.ops.mesh.primitive_uv_sphere_add(segments=48, ring_count=24, radius=body["rad"])
        planet = bpy.context.object

    planet.name = name
    planet.location = (body["dist"], 0, 0)
    planet.rotation_euler = (0, math.radians(body["tilt"]), 0)
    planet.parent = pivot
    bpy.ops.object.shade_smooth()

    p_mat = create_diffuse_mat(f"{name}_Material", body["tex"])
    planet.data.materials.append(p_mat)

    if name == "Saturn":
        bpy.ops.object.empty_add(type='PLAIN_AXES', location=(body["dist"], 0, 0))
        ring_tilt_empty = bpy.context.object
        ring_tilt_empty.name = "SaturnRing_TiltEmpty"
        ring_tilt_empty.rotation_euler = (0, math.radians(body["tilt"]), 0)
        ring_tilt_empty.parent = pivot

        bpy.ops.mesh.primitive_circle_add(vertices=128, radius=body["rad"] * 2.4, fill_type='NGON', location=(0, 0, 0))
        saturn_ring = bpy.context.object
        saturn_ring.name = "SaturnRing"
        saturn_ring.parent = ring_tilt_empty
        r_mat = create_diffuse_mat("SaturnRingMat", "C:/textures/saturnRing.png")
        saturn_ring.data.materials.append(r_mat)
        system_registry["SaturnRing_TiltEmpty"] = ring_tilt_empty

    if name == "Earth":
        # CRITICAL FIX: The moon pivot is placed directly AT Earth's orbital distance (10.0) 
        # as its parent root origin. This decouples the moon completely from Earth's 
        # separate axial spins and protects its orbit radius from wandering.
        bpy.ops.object.empty_add(type='PLAIN_AXES', location=(body["dist"], 0, 0))
        moon_pivot = bpy.context.object
        moon_pivot.name = "Moon_Orbit_Pivot"
        moon_pivot.parent = pivot  

        # Moon is spawned in tight local coordinate distance directly adjacent to Earth's radius surface
        # (Local offset = 0.45 units)
        bpy.ops.mesh.primitive_uv_sphere_add(segments=24, ring_count=12, radius=0.08, location=(body["dist"] + 0.45, 0, 0))
        moon = bpy.context.object
        moon.name = "The_Moon"
        moon.parent = moon_pivot
        bpy.ops.object.shade_smooth()
        m_mat = create_diffuse_mat("MoonMaterial", "C:/textures/moon.jpg", roughness=0.95)
        moon.data.materials.append(m_mat)
        system_registry["Moon"] = moon
        system_registry["Moon_Pivot"] = moon_pivot

    system_registry[name] = planet
    system_registry[f"{name}_Pivot"] = pivot

# =========================================================================
# ☄️ THE ASTEROID BELTS ENGINE
# =========================================================================
def create_asteroid_field(inner_r, outer_r, count, prefix):
    for i in range(count):
        radius = random.uniform(inner_r, outer_r)
        angle = random.uniform(0, math.pi * 2)
        z_offset = random.uniform(-0.18, 0.18)

        bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2, radius=random.uniform(0.02, 0.05))
        ast = bpy.context.object
        ast.name = f"{prefix}_Asteroid_{i}"
        ast.location = (math.cos(angle) * radius, math.sin(angle) * radius, z_offset)

        for vertex in ast.data.vertices:
            vertex.co.x *= random.uniform(1.2, 1.4)
            vertex.co.y *= random.uniform(0.8, 0.9)
            vertex.co.z *= random.uniform(0.7, 0.9)

        bpy.ops.object.shade_smooth()
        ast.data.materials.append(asteroid_mat)

create_asteroid_field(14.5, 16.5, 120, "InnerBelt")
create_asteroid_field(33.0, 36.0, 180, "OuterBelt")

# =========================================================================
# 🎬 CINEMATIC ACTION SYSTEM (KEYFRAMES & TIME PARSING)
# =========================================================================
bpy.ops.object.empty_add(type='PLAIN_AXES', location=(0, 0, 0))
camera_target = bpy.context.object
camera_target.name = "Camera_Target"

bpy.ops.object.camera_add()
camera = bpy.context.object
camera.name = "Cinematic_Camera"
camera.data.lens = 24
camera.parent = camera_target
scene.camera = camera

# =========================================================================
# 💡 LIGHTING RECONSTRUCTION
# =========================================================================
bpy.ops.object.light_add(type='SUN', location=(0, 0, 15))
sun_light = bpy.context.object
sun_light.name = "Dynamic_Solar_Fill"
sun_light.data.energy = 12.0  
sun_light.data.angle = math.radians(15.0)

light_constraint = sun_light.constraints.new(type='TRACK_TO')
light_constraint.target = camera_target
light_constraint.track_axis = 'TRACK_NEGATIVE_Z'
light_constraint.up_axis = 'UP_Y'

bpy.ops.object.light_add(type='SUN', location=(0, 0, 50))
global_fill = bpy.context.object
global_fill.name = "Global_System_Fill"
global_fill.data.energy = 5.0  
global_fill.rotation_euler = (math.radians(45), 0, 0)

bg.inputs['Strength'].default_value = 0.65

# -------------------------------------------------------------------------
bpy.context.preferences.edit.keyframe_new_interpolation_type = 'BEZIER'

# --- PHASE 1: THE GRAND TOUR ---
tour_stops = [
    {"frame": 1,   "target": (0, 0, 0),        "cam_loc": (0, -6, 2.5)},      
    {"frame": 25,  "target": (4.5, 0, 0),      "cam_loc": (4.5, -0.8, 0.2)},  
    {"frame": 50,  "target": (6.5, 0, 0),      "cam_loc": (6.5, -1.2, 0.3)},  
    {"frame": 75,  "target": (10.0, 0, 0),     "cam_loc": (10.0, -1.5, 0.4)},   
    {"frame": 100, "target": (10.45, 0, 0),    "cam_loc": (10.45, -0.4, 0.15)}, 
    {"frame": 120, "target": (13.5, 0, 0),     "cam_loc": (13.5, -1.0, 0.3)}, 
    {"frame": 145, "target": (18.0, 0, 0),     "cam_loc": (18.0, -3.2, 1.2)}, 
    {"frame": 170, "target": (23.0, 0, 0),     "cam_loc": (23.0, -3.8, 1.5)}, 
    {"frame": 195, "target": (27.5, 0, 0),     "cam_loc": (27.5, -2.4, 0.8)}, 
    {"frame": 215, "target": (31.5, 0, 0),     "cam_loc": (31.5, -2.2, 0.8)}, 
    {"frame": 235, "target": (37.0, 0, 0),     "cam_loc": (37.0, -0.8, 0.3)}, 
    {"frame": 255, "target": (0, 0, 0),        "cam_loc": (0, -55.0, 38.0)},  
]

for stop in tour_stops:
    scene.frame_set(stop["frame"])
    camera_target.location = stop["target"]
    camera_target.keyframe_insert(data_path="location")
    camera.location = stop["cam_loc"]
    camera.keyframe_insert(data_path="location")

# Track-to constraint so camera always faces the target empty
scene.frame_set(1)
bpy.ops.object.select_all(action='DESELECT')
camera.select_set(True)
bpy.context.view_layer.objects.active = camera
track_constraint = camera.constraints.new(type='TRACK_TO')
track_constraint.target = camera_target
track_constraint.track_axis = 'TRACK_NEGATIVE_Z'
track_constraint.up_axis = 'UP_Y'

# --- PHASE 2: THE COSMIC DANCE ---
PHASE2_START = 256
bpy.context.preferences.edit.keyframe_new_interpolation_type = 'LINEAR'

simulated_earth_years = 5.0

scene.frame_set(PHASE2_START)
camera_target.location = (0, 0, 0)
camera_target.keyframe_insert(data_path="location")
camera.location = (0, -55.0, 38.0)
camera.keyframe_insert(data_path="location")

scene.frame_set(1440)
camera_target.location = (0, 0, 0)
camera_target.keyframe_insert(data_path="location")
camera.location = (0, -55.0, 38.0)
camera.keyframe_insert(data_path="location")

for name, body in cosmic_manifest.items():
    pivot = system_registry[f"{name}_Pivot"]
    planet = system_registry[name]

    # 1. ORBITAL REVOLUTION
    total_rev_degrees = (simulated_earth_years / body["rev"]) * 360.0
    pivot.rotation_euler.z = 0
    pivot.keyframe_insert(data_path="rotation_euler", frame=PHASE2_START)
    pivot.rotation_euler.z = math.radians(total_rev_degrees)
    pivot.keyframe_insert(data_path="rotation_euler", frame=1440)

    # 2. AXIAL ROTATION
    total_rot_degrees = (simulated_earth_years * 365.25 / body["rot"]) * 360.0
    if abs(body["rot"]) < 1.0:
        total_rot_degrees *= 0.04  

    planet.rotation_euler.z = 0
    planet.keyframe_insert(data_path="rotation_euler", frame=PHASE2_START)
    planet.rotation_euler.z = math.radians(total_rot_degrees)
    planet.keyframe_insert(data_path="rotation_euler", frame=1440)

# =========================================================================
# 🌙 THE MOON'S FIX: LOCAL COORDINATE LOCKED REVOLUTION & ROTATION
# =========================================================================
# By clearing the raw mesh location properties and applying transformation 
# values exclusively inside the local tracking pivot space container, the 
# Moon is forced to stay tightly anchored at 0.45 units out while it orbits.
moon_pivot = system_registry["Moon_Pivot"]
moon_mesh = system_registry["Moon"]

# Reset mesh transforms to lock perfectly inside the tight pivot container space
moon_mesh.location = (0.45, 0, 0) 

moon_rev_degrees = (simulated_earth_years * 365.25 / 27.32) * 360.0

# Pivot handles space orbit around Earth coordinates cleanly
moon_pivot.rotation_euler.z = 0
moon_pivot.keyframe_insert(data_path="rotation_euler", frame=PHASE2_START)
moon_pivot.rotation_euler.z = math.radians(moon_rev_degrees)
moon_pivot.keyframe_insert(data_path="rotation_euler", frame=1440)

# Mesh handles independent tracking axial surface spin
moon_mesh.rotation_euler.z = 0
moon_mesh.keyframe_insert(data_path="rotation_euler", frame=PHASE2_START)
moon_mesh.rotation_euler.z = math.radians(moon_rev_degrees)
moon_mesh.keyframe_insert(data_path="rotation_euler", frame=1440)

# =========================================================================
# 🛰️ SATELLITES SYSTEM (Earth - Realistic Design with Solar Panels)
# =========================================================================
earth_pivot = system_registry["Earth_Pivot"]

# Create realistic satellite material for solar panels
solar_panel_mat = create_emissive_mat("SolarPanelMat", (0.2, 0.3, 0.5, 1.0), 0.6)
sat_body_mat = create_emissive_mat("SatelliteBodyMat", (0.9, 0.9, 0.9, 1.0), 0.4)

# EARTH SATELLITES (3 realistic observation satellites - SCATTERED around Earth)
earth_sat_data = [
    {"name": "Satellite_E1", "distance": 0.60, "speed": 0.1, "angle": 45.0, "z_offset": 0.15},
    {"name": "Satellite_E2", "distance": 0.60, "speed": 0.08, "angle": 165.0, "z_offset": -0.12},
    {"name": "Satellite_E3", "distance": 0.60, "speed": 0.06, "angle": 290.0, "z_offset": 0.08},
]

def create_realistic_satellite(name, distance, angle, z_offset, parent_pivot):
    """Create a satellite with central body and solar panel arrays - positioned at angle around Earth"""
    
    # Calculate position around Earth at given angle
    x_pos = distance * math.cos(math.radians(angle))
    y_pos = distance * math.sin(math.radians(angle))
    
    # Main orbit pivot
    bpy.ops.object.empty_add(type='PLAIN_AXES', location=(10.0, 0, 0))
    sat_pivot = bpy.context.object
    sat_pivot.name = f"{name}_Pivot"
    sat_pivot.parent = parent_pivot
    
    # Central cylindrical body
    bpy.ops.mesh.primitive_cylinder_add(vertices=12, radius=0.025, depth=0.08, location=(x_pos, y_pos, z_offset))
    body = bpy.context.object
    body.name = f"{name}_Body"
    body.parent = sat_pivot
    body.data.materials.append(sat_body_mat)
    bpy.ops.object.shade_smooth()
    
    # Left solar panel array
    bpy.ops.mesh.primitive_cube_add(size=1, location=(x_pos - 0.05, y_pos - 0.08, z_offset))
    left_panel = bpy.context.object
    left_panel.name = f"{name}_LeftPanel"
    left_panel.scale = (0.15, 0.06, 0.05)
    left_panel.parent = sat_pivot
    left_panel.data.materials.append(solar_panel_mat)
    bpy.ops.object.shade_smooth()
    
    # Right solar panel array
    bpy.ops.mesh.primitive_cube_add(size=1, location=(x_pos - 0.05, y_pos + 0.08, z_offset))
    right_panel = bpy.context.object
    right_panel.name = f"{name}_RightPanel"
    right_panel.scale = (0.15, 0.06, 0.05)
    right_panel.parent = sat_pivot
    right_panel.data.materials.append(solar_panel_mat)
    bpy.ops.object.shade_smooth()
    
    # Antenna/sensor extension
    bpy.ops.mesh.primitive_cylinder_add(vertices=8, radius=0.008, depth=0.06, location=(x_pos + 0.04, y_pos, z_offset))
    antenna = bpy.context.object
    antenna.name = f"{name}_Antenna"
    antenna.parent = sat_pivot
    antenna.data.materials.append(create_emissive_mat(f"{name}_AntennaMat", (0.5, 0.5, 0.5, 1.0), 0.3))
    bpy.ops.object.shade_smooth()
    
    system_registry[name] = body
    system_registry[f"{name}_Pivot"] = sat_pivot
    
    return sat_pivot

# Create 3 realistic Earth satellites scattered around Earth
for sat in earth_sat_data:
    sat_pivot = create_realistic_satellite(sat['name'], sat['distance'], sat['angle'], sat['z_offset'], earth_pivot)

# Add orbital animations for Earth satellites during Phase 2
for sat in earth_sat_data:
    sat_pivot = system_registry[f"{sat['name']}_Pivot"]
    sat_pivot.rotation_euler.z = 0
    sat_pivot.keyframe_insert(data_path="rotation_euler", frame=PHASE2_START)
    sat_pivot.rotation_euler.z = math.radians(sat['speed'] * 360.0 * simulated_earth_years)
    sat_pivot.keyframe_insert(data_path="rotation_euler", frame=1440)

# =========================================================================
# ☄️ METEOR SYSTEM - MULTIPLE METEORS WITH FLARES (Fast & Scattered)
# =========================================================================
meteor_mat = create_emissive_mat("MeteorMat", (1.0, 0.6, 0.2, 1.0), 1.5)
flare_mat = create_emissive_mat("FlareMat", (1.0, 0.8, 0.3, 1.0), 2.0)

# Multiple meteor trajectories - scattered entry points and speeds
meteor_data = [
    {
        "name": "Meteor_1",
        "start": (PHASE2_START, (-42.0, 15.0, 38.0)),
        "end": (1440, (48.0, -18.0, 22.0)),
        "flare_offset": 0.35
    },
    {
        "name": "Meteor_2", 
        "start": (PHASE2_START + 80, (-35.0, -12.0, 32.0)),
        "end": (1440, (52.0, 12.0, 18.0)),
        "flare_offset": 0.30
    },
    {
        "name": "Meteor_3",
        "start": (PHASE2_START + 150, (-38.0, 8.0, 36.0)),
        "end": (1440, (50.0, -8.0, 20.0)),
        "flare_offset": 0.32
    },
    {
        "name": "Meteor_4",
        "start": (PHASE2_START + 40, (-40.0, -18.0, 34.0)),
        "end": (1440, (45.0, 15.0, 19.0)),
        "flare_offset": 0.28
    },
    {
        "name": "Meteor_5",
        "start": (PHASE2_START + 110, (-36.0, 10.0, 35.0)),
        "end": (1440, (49.0, -14.0, 21.0)),
        "flare_offset": 0.33
    },
]

for meteor_info in meteor_data:
    # Main meteor body
    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=3, radius=0.15)
    meteor = bpy.context.object
    meteor.name = meteor_info["name"]
    meteor.data.materials.append(meteor_mat)
    bpy.ops.object.shade_smooth()
    
    # Deform meteor to look irregular/rocky
    for vertex in meteor.data.vertices:
        vertex.co.x *= random.uniform(0.8, 1.3)
        vertex.co.y *= random.uniform(0.7, 1.2)
        vertex.co.z *= random.uniform(0.75, 1.15)
    
    system_registry[meteor_info["name"]] = meteor
    
    # Create flare trail (stretched elongated glow behind meteor)
    bpy.ops.mesh.primitive_cylinder_add(vertices=16, radius=0.08, depth=1.0)
    flare = bpy.context.object
    flare.name = f"{meteor_info['name']}_Flare"
    flare.data.materials.append(flare_mat)
    flare.parent = meteor
    flare.location.z = -0.5  # Behind the meteor in Z
    bpy.ops.object.shade_smooth()
    
    system_registry[f"{meteor_info['name']}_Flare"] = flare
    
    # Keyframe meteor trajectory (fast passage through system)
    start_frame, start_pos = meteor_info["start"]
    end_frame, end_pos = meteor_info["end"]
    
    scene.frame_set(start_frame)
    meteor.location = start_pos
    meteor.keyframe_insert(data_path="location")
    meteor.rotation_euler = (
        math.radians(random.uniform(0, 360)),
        math.radians(random.uniform(0, 360)),
        math.radians(random.uniform(0, 360))
    )
    meteor.keyframe_insert(data_path="rotation_euler")
    
    scene.frame_set(end_frame)
    meteor.location = end_pos
    meteor.keyframe_insert(data_path="location")
    meteor.rotation_euler = (
        math.radians(random.uniform(0, 360)),
        math.radians(random.uniform(0, 360)),
        math.radians(random.uniform(0, 360))
    )
    meteor.keyframe_insert(data_path="rotation_euler")

print("✓ Earth satellites added (3 scattered observation satellites with solar panels)")
print("✓ Multiple meteors initialized (5 fast meteors with flares)")
print("✓ Varied trajectories - scattered entry/exit points")
print("✓ Safe passage: Outer region only, no planetary collision risk!")

# =========================================================================
# 💾 RENDER OUTPUT CONFIGURATION
# =========================================================================
# Change this path to wherever you want the final video saved:
scene.render.filepath = "C:/textures/planetary_tour.mp4"

# Set up the file format as an MP4 video
scene.render.image_settings.file_format = 'FFMPEG'
scene.render.ffmpeg.format = 'MPEG4'
scene.render.ffmpeg.codec = 'H264'
scene.render.ffmpeg.constant_rate_factor = 'HIGH' # Keeps quality crisp

scene.frame_set(1)
print("System Complete! Ready to render the solar system tour with satellites and meteor.")