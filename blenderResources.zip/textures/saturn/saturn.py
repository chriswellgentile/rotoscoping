import bpy
import math
import random

# RESET SCENE
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

# RENDER ENGINE (Eevee Next / 5.1 API Compatibility)
scene = bpy.context.scene
scene.render.engine = 'BLENDER_EEVEE'
if hasattr(scene, "eevee"):
    if hasattr(scene.eevee, "taa_render_samples"):
        scene.eevee.taa_render_samples = 16
    elif hasattr(scene.eevee, "ta_samples"):
        scene.eevee.ta_samples = 16
    else:
        scene.eevee.aa_samples = 16

# FPS & DURATION (EXACTLY 10 SECONDS @ 24 FPS = 240 FRAMES)
scene.frame_start = 1
scene.frame_end = 240   
scene.render.fps = 24

# RESOLUTION
scene.render.resolution_x = 1280
scene.render.resolution_y = 1280

# ----------------------------
# 🌌 STAR BACKGROUND
# ----------------------------
world = scene.world
world.use_nodes = True
nodes = world.node_tree.nodes
links = world.node_tree.links
nodes.clear()

bg = nodes.new(type='ShaderNodeBackground')
output = nodes.new(type='ShaderNodeOutputWorld')
noise = nodes.new(type='ShaderNodeTexNoise')
ramp = nodes.new(type='ShaderNodeValToRGB')
math_mult = nodes.new(type='ShaderNodeMath')

noise.inputs['Scale'].default_value = 500.0
noise.inputs['Detail'].default_value = 15.0
noise.inputs['Roughness'].default_value = 0.9

ramp.color_ramp.interpolation = 'CONSTANT'
ramp.color_ramp.elements[0].position = 0.0
ramp.color_ramp.elements[0].color = (0, 0, 0, 1)
ramp.color_ramp.elements[1].position = 0.63      
ramp.color_ramp.elements[1].color = (1, 1, 1, 1)

math_mult.operation = 'MULTIPLY'
math_mult.inputs[1].default_value = 8.0

links.new(noise.outputs['Fac'], ramp.inputs['Fac'])
links.new(ramp.outputs['Color'], math_mult.inputs[0])
links.new(math_mult.outputs['Value'], bg.inputs['Color'])
links.new(bg.outputs['Background'], output.inputs['Surface'])

# =========================================================================
# 1. CREATE SATURN (OBLATE SPHEROID WITH SCIENTIFIC TILT) & SATURN RING
# =========================================================================
bpy.ops.mesh.primitive_uv_sphere_add(segments=64, ring_count=32, radius=1.4)
saturn = bpy.context.object
saturn.name = "Saturn"

# Flatten along Z-axis for oblateness, then tilt 26.73 degrees along the X-axis
saturn.scale.z = 0.85
saturn.rotation_euler = (math.radians(26.73), 0, 0)
bpy.ops.object.shade_smooth()

sat_mat = bpy.data.materials.new(name="SaturnMaterial")
sat_mat.use_nodes = True
sat_nodes = sat_mat.node_tree.nodes
sat_links = sat_mat.node_tree.links
sat_nodes.clear()

tex_sat = sat_nodes.new(type='ShaderNodeTexImage')
try:
    tex_sat.image = bpy.data.images.load("C:/textures/saturn/saturn_color.jpg")
except:
    print("Saturn texture not found.")

bsdf_sat = sat_nodes.new(type='ShaderNodeBsdfPrincipled')
bsdf_sat.inputs['Roughness'].default_value = 0.60     
out_sat = sat_nodes.new(type='ShaderNodeOutputMaterial')

sat_links.new(tex_sat.outputs['Color'], bsdf_sat.inputs['Base Color'])
sat_links.new(bsdf_sat.outputs['BSDF'], out_sat.inputs['Surface'])
saturn.data.materials.append(sat_mat)

# --- FIX: CREATE THE RING AS A FLAT GRID DISK FOR NATIVE UV GENERATION ---
# This ensures Blender inherently maps the square PNG from the center outwards
# --- FIX: CORRECT BLENDER API KEYWORDS FOR GRID GENERATION ---
# Changed subdivisions_x/y to x_subdivisions/y_subdivisions
bpy.ops.mesh.primitive_grid_add(x_subdivisions=2, y_subdivisions=2, size=6.4)
saturnRing = bpy.context.object
saturnRing.name = "saturnRing"

# Parent the ring to Saturn so it inherits the planet's axial tilt perfectly
saturnRing.parent = saturn

# =========================================================================
# 🛠️ FIXED CYLINDRICAL/RADIUS MASK FOR PERFECT RING MAPPING
# =========================================================================
ring_mat = bpy.data.materials.new(name="SaturnRingMaterial")
ring_mat.use_nodes = True
r_nodes = ring_mat.node_tree.nodes
r_links = ring_mat.node_tree.links
r_nodes.clear()

# Force alpha transparency blending in Eevee
if hasattr(ring_mat, "blend_method"):
    ring_mat.blend_method = 'BLEND'

# Nodes for geometry and coordinate generation
tex_coord = r_nodes.new(type='ShaderNodeTexCoord')
tex_ring = r_nodes.new(type='ShaderNodeTexImage')
try:
    tex_ring.image = bpy.data.images.load("C:/textures/saturn/saturnRing.png")
except:
    print("Saturn ring texture not found.")

bsdf_ring = r_nodes.new(type='ShaderNodeBsdfPrincipled')
bsdf_ring.inputs['Roughness'].default_value = 0.80
out_ring = r_nodes.new(type='ShaderNodeOutputMaterial')

# --- THE MATH MATRIX: Cuts square mapping into a perfect circular ring ---
# 1. Separate UV coordinates to calculate distance from center
sep_xyz = r_nodes.new(type='ShaderNodeSeparateXYZ')

# 2. Shift center from (0,0) corner to (0.5, 0.5) center of the grid plane
sub_x = r_nodes.new(type='ShaderNodeMath')
sub_x.operation = 'SUBTRACT'
sub_x.inputs[1].default_value = 0.5

sub_y = r_nodes.new(type='ShaderNodeMath')
sub_y.operation = 'SUBTRACT'
sub_y.inputs[1].default_value = 0.5

# 3. Square the values: x^2 and y^2
pwr_x = r_nodes.new(type='ShaderNodeMath')
pwr_x.operation = 'POWER'
pwr_x.inputs[1].default_value = 2.0

pwr_y = r_nodes.new(type='ShaderNodeMath')
pwr_y.operation = 'POWER'
pwr_y.inputs[1].default_value = 2.0

# 4. Add them together: x^2 + y^2
add_xy = r_nodes.new(type='ShaderNodeMath')
add_xy.operation = 'ADD'

# 5. Take the square root: sqrt(x^2 + y^2) = Absolute radius distance from center
sqrt_radius = r_nodes.new(type='ShaderNodeMath')
sqrt_radius.operation = 'SQRT'

# 6. Map the radius profile directly into a color ramp to act as our transparency window
# This mathematically crops the square corners off completely
ring_clipper = r_nodes.new(type='ShaderNodeValToRGB')
ring_clipper.color_ramp.interpolation = 'LINEAR'
# Elements control: [Inner Hole Limit, Ring Start, Ring End, Outer Edge Limit]
ring_clipper.color_ramp.elements[0].position = 0.18   # Inner hole boundary
ring_clipper.color_ramp.elements[0].color = (0, 0, 0, 1) # Invisible core
ring_clipper.color_ramp.elements.new(0.22)
ring_clipper.color_ramp.elements[1].color = (1, 1, 1, 1) # Full texture visibility
ring_clipper.color_ramp.elements.new(0.48)
ring_clipper.color_ramp.elements[2].color = (1, 1, 1, 1) # Ring body span
ring_clipper.color_ramp.elements[3].position = 0.50   # Outer boundary cap
ring_clipper.color_ramp.elements[3].color = (0, 0, 0, 1) # Invisible square corners

# 7. Mix image alpha channel with our calculated geometric circle mask
mix_alpha = r_nodes.new(type='ShaderNodeMath')
mix_alpha.operation = 'MULTIPLY'

# LINKING THE ENGINE CHANNELS
r_links.new(tex_coord.outputs['UV'], sep_xyz.inputs['Vector'])
r_links.new(sep_xyz.outputs['X'], sub_x.inputs[0])
r_links.new(sep_xyz.outputs['Y'], sub_y.inputs[0])

r_links.new(sub_x.outputs['Value'], pwr_x.inputs[0])
r_links.new(sub_y.outputs['Value'], pwr_y.inputs[0])
r_links.new(pwr_x.outputs['Value'], add_xy.inputs[0])
r_links.new(pwr_y.outputs['Value'], add_xy.inputs[1])
r_links.new(add_xy.outputs['Value'], sqrt_radius.inputs[0])
r_links.new(sqrt_radius.outputs['Value'], ring_clipper.inputs['Fac'])

# Blend PNG color data and combine alpha systems
r_links.new(tex_ring.outputs['Color'], bsdf_ring.inputs['Base Color'])
r_links.new(tex_ring.outputs['Alpha'], mix_alpha.inputs[0])
r_links.new(ring_clipper.outputs['Color'], mix_alpha.inputs[1])

# Send complete calculation package to material output
r_links.new(mix_alpha.outputs['Value'], bsdf_ring.inputs['Alpha'])
r_links.new(bsdf_ring.outputs['BSDF'], out_ring.inputs['Surface'])
saturnRing.data.materials.append(ring_mat)
# =========================================================================
# 🌙 HELPER: GENERATE SYSTEM SATELLITES
# =========================================================================
def generate_saturnian_moon(name, radius, texture_path, shape_type="sphere"):
    if shape_type == "sphere":
        bpy.ops.mesh.primitive_uv_sphere_add(segments=24, ring_count=12, radius=radius)
    else:
        bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=3, radius=radius)
        
    moon_obj = bpy.context.object
    moon_obj.name = name
    
    if shape_type == "chaotic_potato":  # Hyperion style
        for vertex in moon_obj.data.vertices:
            vertex.co.x *= 1.55
            vertex.co.y *= 1.10
            vertex.co.z *= 0.70
    elif shape_type == "minor_rock":    # Minor Moons style
        for vertex in moon_obj.data.vertices:
            vertex.co.x *= random.uniform(1.30, 1.50)
            vertex.co.y *= random.uniform(0.75, 0.95)
            vertex.co.z *= random.uniform(0.65, 0.80)

    bpy.ops.object.shade_smooth()
    
    mat = bpy.data.materials.new(name=f"{name}_Mat")
    mat.use_nodes = True
    m_nodes = mat.node_tree.nodes
    m_links = mat.node_tree.links
    m_nodes.clear()
    
    tex = m_nodes.new(type='ShaderNodeTexImage')
    try:
        tex.image = bpy.data.images.load(texture_path)
    except:
        pass
        
    bsdf = m_nodes.new(type='ShaderNodeBsdfPrincipled')
    bsdf.inputs['Roughness'].default_value = 0.95
    out = m_nodes.new(type='ShaderNodeOutputMaterial')
    
    m_links.new(tex.outputs['Color'], bsdf.inputs['Base Color'])
    m_links.new(bsdf.outputs['BSDF'], out.inputs['Surface'])
    moon_obj.data.materials.append(mat)
    
    return moon_obj

# =========================================================================
# 2. POPULATE THE SYSTEM (COMPACT CLOSER MOON DISTANCES)
# =========================================================================
random.seed(555)
moons_data = []

major_configs = [
    {"name": "Mimas", "rad": 0.032, "dist": 1.8, "period": 0.942, "shape": "sphere", "tex": "C:/textures/saturn/mimas.jpg"},
    {"name": "Enceladus", "rad": 0.038, "dist": 2.2, "period": 1.370, "shape": "sphere", "tex": "C:/textures/saturn/enceladus.jpg"},
    {"name": "Tethys", "rad": 0.048, "dist": 2.6, "period": 1.888, "shape": "sphere", "tex": "C:/textures/saturn/tethys.jpg"},
    {"name": "Dione", "rad": 0.052, "dist": 3.1, "period": 2.737, "shape": "sphere", "tex": "C:/textures/saturn/dione.jpg"},
    {"name": "Titan", "rad": 0.120, "dist": 3.9, "period": 15.945, "shape": "sphere", "tex": "C:/textures/saturn/titan.jpg"},
    {"name": "Hyperion", "rad": 0.030, "dist": 4.6, "period": 21.276, "shape": "chaotic_potato", "tex": "C:/textures/saturn/hyperion.jpg"},
    {"name": "Iapetus", "rad": 0.058, "dist": 5.5, "period": 79.330, "shape": "sphere", "tex": "C:/textures/saturn/iapetus.jpg"}
]

for config in major_configs:
    bpy.ops.object.empty_add(type='PLAIN_AXES', location=(0, 0, 0))
    orbit_pivot = bpy.context.object
    orbit_pivot.name = f"{config['name']}_Orbit_Center"
    orbit_pivot.rotation_euler = (math.radians(26.73), 0, 0)
    
    moon_obj = generate_saturnian_moon(config['name'], config['rad'], config['tex'], shape_type=config['shape'])
    
    start_angle = random.uniform(0, math.pi * 2)
    moon_obj.location = (math.cos(start_angle) * config['dist'], math.sin(start_angle) * config['dist'], random.uniform(-0.02, 0.02))
    moon_obj.parent = orbit_pivot
    
    moons_data.append({"pivot": orbit_pivot, "moon": moon_obj, "period": config['period']})

# --- Generate 267 Compressed Minor Moons ---
minor_moon_texture = "C:/textures/saturn/moon.jpg"

for i in range(267):
    name = f"Minor_Moon_{i+1}"
    bpy.ops.object.empty_add(type='PLAIN_AXES', location=(0, 0, 0))
    orbit_pivot = bpy.context.object
    orbit_pivot.name = f"{name}_Orbit_Center"
    orbit_pivot.rotation_euler = (math.radians(26.73), 0, 0)
    
    dist = random.uniform(6.0, 8.5)
    rad = random.uniform(0.012, 0.024)
    period = 85.0 + (dist ** 1.5) * random.uniform(2.0, 5.0)
    
    moon_obj = generate_saturnian_moon(name, rad, minor_moon_texture, shape_type="minor_rock")
    
    start_angle = random.uniform(0, math.pi * 2)
    z_tilt = random.uniform(-0.4, 0.4) 
    moon_obj.location = (math.cos(start_angle) * dist, math.sin(start_angle) * dist, z_tilt)
    moon_obj.parent = orbit_pivot
    
    moons_data.append({"pivot": orbit_pivot, "moon": moon_obj, "period": period})

# =========================================================================
# 3. SCORPIO CONSTELLATION
# =========================================================================
star_mat = bpy.data.materials.new(name="StarMaterial")
star_mat.use_nodes = True
s_nodes = star_mat.node_tree.nodes
s_nodes.clear()
node_emit = s_nodes.new(type='ShaderNodeEmission')
node_emit.inputs['Strength'].default_value = 6.0
node_emit.inputs['Color'].default_value = (0.85, 0.9, 1.0, 1.0)
node_out = s_nodes.new(type='ShaderNodeOutputMaterial')
star_mat.node_tree.links.new(node_emit.outputs['Emission'], node_out.inputs['Surface'])

scorpio_stars_coords = [
    (-7.70, 12, 6.15), (-7.95, 12, 5.95), (-7.85, 12, 5.70), (-7.50, 12, 5.60),
    (-7.25, 12, 5.65), (-7.00, 12, 6.20), (-6.75, 12, 6.60), (-6.55, 12, 6.70),
    (-6.10, 12, 7.00), (-6.00, 12, 6.75), (-6.20, 12, 6.50)
]

for idx, coord in enumerate(scorpio_stars_coords):
    size = 0.12 if idx == 7 else random.uniform(0.04, 0.06)
    bpy.ops.mesh.primitive_uv_sphere_add(segments=16, ring_count=8, radius=size, location=coord)
    star = bpy.context.object
    star.name = f"Scorpio_Star_{idx}"
    star.data.materials.append(star_mat)
    
    line_mat = bpy.data.materials.new(name="ConstellationLineMaterial")
line_mat.use_nodes = True
l_nodes = line_mat.node_tree.nodes
l_nodes.clear()
l_emit = l_nodes.new(type='ShaderNodeEmission')
l_emit.inputs['Strength'].default_value = 2.0  
l_emit.inputs['Color'].default_value = (0.4, 0.6, 1.0, 1.0) 
l_out = l_nodes.new(type='ShaderNodeOutputMaterial')
line_mat.node_tree.links.new(l_emit.outputs['Emission'], l_out.inputs['Surface'])

scorpio_line_sequences = [
    [0, 1, 2, 3, 4, 5, 6],                                                                             
    [7, 8],
    [7, 9],
    [7, 10]                                             
]

for sequence_idx, seq in enumerate(scorpio_line_sequences):
    curve_data = bpy.data.curves.new(name=f"Scorpio_LineData_{sequence_idx}", type='CURVE')
    curve_data.dimensions = '3D'
    curve_data.bevel_depth = 0.006  
    
    polyline = curve_data.splines.new(type='POLY')
    polyline.points.add(len(seq) - 1)
    
    for point_idx, star_idx in enumerate(seq):
        coord = scorpio_stars_coords[star_idx]
        polyline.points[point_idx].co = (coord[0], coord[1], coord[2], 1.0)
        
    curve_obj = bpy.data.objects.new(f"Scorpio_Line_{sequence_idx}", curve_data)
    bpy.context.collection.objects.link(curve_obj)
    curve_obj.data.materials.append(line_mat)

# =========================================================================
# LIGHTING & CAMERA
# =========================================================================
bpy.ops.object.light_add(type='SUN', location=(15, -18, 15))
key_light = bpy.context.object
key_light.data.energy = 9.0
key_light.rotation_euler = (math.radians(55), 0, math.radians(-30))

bpy.ops.object.camera_add(location=(0, -18.0, -2))
camera = bpy.context.object
camera.rotation_euler = (math.radians(90), 0, 0)
camera.data.lens = 35 
scene.camera = camera

# =========================================================================
# ⏱️ SCALE ANIMATION
# =========================================================================
original_interpolation = bpy.context.preferences.edit.keyframe_new_interpolation_type
bpy.context.preferences.edit.keyframe_new_interpolation_type = 'LINEAR'

earth_days_to_simulate = 5
saturn_sidereal_day = 0.444
saturn_total_degrees = (earth_days_to_simulate / saturn_sidereal_day) * 360

saturn.keyframe_insert(data_path="rotation_euler", frame=1)
saturn.rotation_euler = (math.radians(26.73), 0, math.radians(saturn_total_degrees))
saturn.keyframe_insert(data_path="rotation_euler", frame=240)

for m_data in moons_data:
    pivot_obj = m_data["pivot"]
    moon_mesh = m_data["moon"]
    period = m_data["period"]
    
    total_degrees = (earth_days_to_simulate / period) * 360
    
    pivot_obj.keyframe_insert(data_path="rotation_euler", frame=1)
    pivot_obj.rotation_euler = (math.radians(26.73), 0, math.radians(total_degrees))
    pivot_obj.keyframe_insert(data_path="rotation_euler", frame=240)
    
    moon_mesh.rotation_euler = (0, 0, 0)
    moon_mesh.keyframe_insert(data_path="rotation_euler", frame=1)
    moon_mesh.rotation_euler = (0, 0, math.radians(total_degrees))
    moon_mesh.keyframe_insert(data_path="rotation_euler", frame=240)

bpy.context.preferences.edit.keyframe_new_interpolation_type = original_interpolation

# OUTPUT SETTINGS
scene.render.filepath = "C:/blender/saturn_tilted_close_system.mp4"
scene.render.image_settings.file_format = 'FFMPEG'
scene.render.ffmpeg.format = 'MPEG4'
print("Done! Core mesh updated to flat grid. UV mappings and Eevee Alpha blending routes established.")