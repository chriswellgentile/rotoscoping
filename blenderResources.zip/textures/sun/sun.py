import bpy
import math
import random

# RESET SCENE
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

# RENDER ENGINE (Eevee Next / 5.1 API Compatibility)
scene = bpy.context.scene
scene.render.engine = 'BLENDER_EEVEE'
if hasattr(scene, "eevee"):
    if hasattr(scene.eevee, "taa_render_samples"):
        scene.eevee.taa_render_samples = 16
    elif hasattr(scene.eevee, "ta_samples"):
        scene.eevee.ta_samples = 16
    else:
        scene.eevee.aa_samples = 16

# FPS & DURATION (EXACTLY 10 SECONDS @ 24 FPS = 240 FRAMES)
scene.frame_start = 1
scene.frame_end = 240   
scene.render.fps = 24

# RESOLUTION
scene.render.resolution_x = 1280
scene.render.resolution_y = 1280

# ----------------------------
# 🌌 STAR BACKGROUND
# ----------------------------
world = scene.world
world.use_nodes = True
nodes = world.node_tree.nodes
links = world.node_tree.links
nodes.clear()

bg = nodes.new(type='ShaderNodeBackground')
output = nodes.new(type='ShaderNodeOutputWorld')
noise = nodes.new(type='ShaderNodeTexNoise')
ramp = nodes.new(type='ShaderNodeValToRGB')
math_mult = nodes.new(type='ShaderNodeMath')

noise.inputs['Scale'].default_value = 500.0
noise.inputs['Detail'].default_value = 15.0
noise.inputs['Roughness'].default_value = 0.9

ramp.color_ramp.interpolation = 'CONSTANT'
ramp.color_ramp.elements[0].position = 0.0
ramp.color_ramp.elements[0].color = (0, 0, 0, 1)
ramp.color_ramp.elements[1].position = 0.63      
ramp.color_ramp.elements[1].color = (1, 1, 1, 1)

math_mult.operation = 'MULTIPLY'
math_mult.inputs[1].default_value = 8.0

links.new(noise.outputs['Fac'], ramp.inputs['Fac'])
links.new(ramp.outputs['Color'], math_mult.inputs[0])
links.new(math_mult.outputs['Value'], bg.inputs['Color'])
links.new(bg.outputs['Background'], output.inputs['Surface'])

# =========================================================================
# 1. CREATE THE SUN (PURE CORE SPHERE)
# =========================================================================
bpy.ops.mesh.primitive_uv_sphere_add(segments=64, ring_count=32, radius=2.2)
sun = bpy.context.object
sun.name = "Sun"
bpy.ops.object.shade_smooth()

sun_mat = bpy.data.materials.new(name="SunMaterial")
sun_mat.use_nodes = True
s_nodes = sun_mat.node_tree.nodes
s_links = sun_mat.node_tree.links
s_nodes.clear()

tex_sun = s_nodes.new(type='ShaderNodeTexImage')
try:
    tex_sun.image = bpy.data.images.load("C:/textures/sun_color.jpg")
except:
    print("Sun texture map missing, running default material output.")

emit_sun = s_nodes.new(type='ShaderNodeEmission')
emit_sun.inputs['Strength'].default_value = 4.0
out_sun = s_nodes.new(type='ShaderNodeOutputMaterial')

s_links.new(tex_sun.outputs['Color'], emit_sun.inputs['Color'])
s_links.new(emit_sun.outputs['Emission'], out_sun.inputs['Surface'])
sun.data.materials.append(sun_mat)

# =========================================================================
# 2. SCORPIO CONSTELLATION
# =========================================================================
star_mat = bpy.data.materials.new(name="StarMaterial")
star_mat.use_nodes = True
st_nodes = star_mat.node_tree.nodes
st_nodes.clear()
node_emit = st_nodes.new(type='ShaderNodeEmission')
node_emit.inputs['Strength'].default_value = 6.0
node_emit.inputs['Color'].default_value = (0.85, 0.9, 1.0, 1.0)
node_out = st_nodes.new(type='ShaderNodeOutputMaterial')
star_mat.node_tree.links.new(node_emit.outputs['Emission'], node_out.inputs['Surface'])

scorpio_stars_coords = [
    (-5.70, 14, 4.15), (-5.95, 14, 3.95), (-5.85, 14, 3.70), (-5.50, 14, 3.60),
    (-5.25, 14, 3.65), (-5.00, 14, 4.20), (-4.75, 14, 4.60), (-4.55, 14, 4.70),
    (-4.10, 14, 5.00), (-4.00, 14, 4.75), (-4.20, 14, 4.50)
]

for idx, coord in enumerate(scorpio_stars_coords):
    size = 0.08 if idx == 7 else random.uniform(0.03, 0.04)
    bpy.ops.mesh.primitive_uv_sphere_add(segments=16, ring_count=8, radius=size, location=coord)
    star = bpy.context.object
    star.name = f"Scorpio_Star_{idx}"
    star.data.materials.append(star_mat)

# =========================================================================
# LIGHTING & CAMERA
# =========================================================================
bpy.ops.object.light_add(type='POINT', location=(0, 0, 0))
core_light = bpy.context.object
core_light.data.energy = 500.0
core_light.data.color = (1.0, 0.6, 0.2)

bpy.ops.object.camera_add(location=(0, -8.5, 0))
camera = bpy.context.object
camera.rotation_euler = (math.radians(90), 0, 0)
camera.data.lens = 30 
scene.camera = camera

# =========================================================================
# ⏱️ ANIMATION
# =========================================================================
original_interpolation = bpy.context.preferences.edit.keyframe_new_interpolation_type
bpy.context.preferences.edit.keyframe_new_interpolation_type = 'LINEAR'

earth_days_to_simulate = 5
sun_equatorial_period = 25.05
sun_total_degrees = (earth_days_to_simulate / sun_equatorial_period) * 360

# KEYFRAME CENTRAL AXIAL SOLAR ROTATION
sun.rotation_euler = (0, 0, 0)
sun.keyframe_insert(data_path="rotation_euler", frame=1)
sun.rotation_euler = (0, 0, math.radians(sun_total_degrees))
sun.keyframe_insert(data_path="rotation_euler", frame=240)

bpy.context.preferences.edit.keyframe_new_interpolation_type = original_interpolation

# OUTPUT SETTINGS
scene.render.filepath = "C:/blender/sun_solo_clean.mp4"
scene.render.image_settings.file_format = 'FFMPEG'
scene.render.ffmpeg.format = 'MPEG4'
print("Done! Solar prominences removed. Clean surface model execution complete.")